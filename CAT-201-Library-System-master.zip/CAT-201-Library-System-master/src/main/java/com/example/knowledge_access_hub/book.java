package com.example.knowledge_access_hub;

import javafx.scene.control.Alert;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class book {
    private String title, author, ISBN, status, borrowerName, IC, Date;

    // Getter for Title
    public String getTitle() {
        return title;
    }

    // Getter for Author
    public String getAuthor() {
        return author;
    }

    // Getter for ISBN
    public String getISBN() {
        return ISBN;
    }

    // Getter for Status
    public String getStatus() {
        return status;
    }

    // Getter for Borrower Name
    public String getBorrowerName() {
        return borrowerName;
    }

    // Getter for IC
    public String getIC() {
        return IC;
    }

    // Getter for Date
    public String getDate() {
        return Date;
    }

    // Setter for Status
    public void setStatus(String stat) {
        status = stat;
    }

    // Method to initialize the book's fields
    public void setVal(String bookT, String name, String isbn, String s, String borrowerN, String ic, String date) {
        title = bookT;
        author = name;
        ISBN = isbn; // Ensure the ISBN field is set here
        status = s;
        borrowerName = borrowerN;
        IC = ic;
        Date = date;
    }

    @Override
    public String toString() {
        // Format title, author, and ISBN for display
        return String.format("%-20s%-20s%-20s", title, author, ISBN);
    }

    // Borrow Book Logic
    public void borrowBook(String borrowerN, String ic, String date) {
        if ("Available".equals(status)) {
            status = "Borrowed";
            borrowerName = borrowerN;
            IC = ic;
            Date = date;
        }
    }

    // Return Book Logic
    public void returnBook() {
        if ("Borrowed".equals(status)) {
            status = "Available";
            borrowerName = "null";
            IC = null;
            Date = null;
        }
    }

    // Display Book Details in a Dialog
    public void displayBookDetails(book bookDetails, DashboardController dash) {
        library lib = new library();

        // Create a custom dialog
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Book Details");

        // Set the header text
        dialog.setHeaderText(bookDetails.getTitle());

        // Create the content (you can use VBox, HBox, or other layouts)
        VBox content = new VBox(10);
        content.getChildren().addAll(
                new Label("Author: " + bookDetails.author),
                new Label("ISBN: " + bookDetails.ISBN),
                new Label("Status: " + bookDetails.status),
                new Label("Borrower: " + ("null".equals(bookDetails.borrowerName) ? "-" : bookDetails.borrowerName))
        );

        // Add a button for deletion
        Button customButton = new Button("Delete");
        customButton.setOnAction(e -> {
            // Confirmation alert
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Book");
            alert.setHeaderText("Are you sure you want to delete this book?");
            alert.setContentText("The book with title: '" + bookDetails.title + "' will be deleted.");

            // Set alert to always be on top
            Stage alertStage = (Stage) alert.getDialogPane().getScene().getWindow();
            alertStage.setAlwaysOnTop(true);

            // Handle the user's response
            alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    lib.deleteBookByTitle(bookDetails.getTitle());
                    lib.updateBookListInFile();
                    dialog.close();
                    dash.ViewAllBook();
                }
            });
        });

        content.getChildren().add(customButton);

        // Set the content in the dialog
        dialog.getDialogPane().setContent(content);

        // Adjust the dialog size
        dialog.getDialogPane().setPrefWidth(400);
        dialog.getDialogPane().setPrefHeight(300);

        // Add a default close button
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);

        // Customize the dialog's stage
        Stage stage = (Stage) dialog.getDialogPane().getScene().getWindow();
        stage.setAlwaysOnTop(true);

        dialog.showAndWait();
    }
}
