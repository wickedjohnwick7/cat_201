package com.example.knowledge_access_hub;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class LoginController {

    public LoginController() {
        loadAccount();
    }

    private Account accObj = new Account();
    private ArrayList<Account> AccountList = new ArrayList<>();
    private final String csvFile = "src/main/resources/Account.csv"; // file path

    @FXML
    private TextField UserCode;

    @FXML
    private PasswordField PasswordField;

    @FXML
    private TextField PasswordVisible;

    @FXML
    private CheckBox TogglePasswordButton;

    // Use a BooleanProperty to toggle visibility state
    private final BooleanProperty isPasswordVisible = new SimpleBooleanProperty(false);

    @FXML
    private void initialize() {
        // Bind visibility properties between PasswordField and TextField
        PasswordVisible.managedProperty().bind(isPasswordVisible);
        PasswordVisible.visibleProperty().bind(isPasswordVisible);
        PasswordField.managedProperty().bind(isPasswordVisible.not());
        PasswordField.visibleProperty().bind(isPasswordVisible.not());

        // Bind text properties between the two fields
        PasswordVisible.textProperty().bindBidirectional(PasswordField.textProperty());

        // Set button action
        TogglePasswordButton.setOnAction(event -> togglePasswordVisibility());
    }

    private void togglePasswordVisibility() {
        // Toggle the BooleanProperty value
        isPasswordVisible.set(!isPasswordVisible.get());
        // Update button text
        TogglePasswordButton.setText(isPasswordVisible.get() ? "Hide Password" : "Show Password");
    }

    @FXML
    protected void onLoginButtonClick() {
        loadAccount();
        String userCode = UserCode.getText().trim();
        String password = PasswordField.isVisible() ? PasswordField.getText().trim() : PasswordVisible.getText().trim();

        if (userCode.isEmpty() || password.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR); // Error alert type
            alert.setTitle("Invalid Input");
            alert.setHeaderText(null); // No header text
            alert.setContentText("Both USER CODE and PASSWORD fields must be filled in to log into the account");
            alert.showAndWait(); // Show the alert and wait for user response
            return; // Exit method if validation fails
        }

        boolean isValidAccount = false;
        for (Account account : AccountList) {
            if (account.getCode().equals(userCode) && account.getPass().equals(password)) {
                isValidAccount = true;
                break;
            }
        }

        if (isValidAccount) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Login Successful");
            alert.setHeaderText(null);
            alert.setContentText("Welcome, " + userCode + "!");
            alert.showAndWait();

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
                Parent root = loader.load();

                // Pass the userCode to the dashboard controller
                DashboardController dashboardController = loader.getController();
                System.out.println("The userCOde: " + UserCode.getText());
                //dashboardController.setAccountName(A_Variable= UserCode.getText());

                System.out.println("The account name had been passed to the dashboard page: " + UserCode.getText().trim());

                Stage stage = (Stage) UserCode.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.setTitle("Main Page");
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText(null);
            alert.setContentText("Invalid USER CODE or PASSWORD.");
            alert.showAndWait();
        }
    }

    public void loadAccount() {
        AccountList.clear();
        String line;
        File myFile = new File(csvFile);
        if (myFile.exists()) {
            try (BufferedReader read = new BufferedReader(new FileReader(myFile))) {
                while ((line = read.readLine()) != null) {
                    String[] dataColumn = line.split(",");
                    if (dataColumn.length == 2) {
                        Account accountObj = new Account();
                        accountObj.setVal(dataColumn[0], dataColumn[1]);
                        AccountList.add(accountObj);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Accounts loaded: " + AccountList.size());
        for (int i = 0; i < AccountList.size(); i++) {
            System.out.println("Entry " + (i + 1) + ": " + AccountList.get(i));
        }
    }
}
