package com.example.knowledge_access_hub;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class addBookController {

    private library libObj = new library();

    @FXML
    private TextField addBookTitle;

    @FXML
    private TextField addBookAuthor;

    @FXML
    private TextField addBookISBN;

    @FXML
    private TextField addBookStatus;

    @FXML
    private TextField addBookBorrowerName;

    @FXML
    private TextArea searchResult;

    @FXML
    private ChoiceBox<String> searchType;

    @FXML
    protected void onAddButtonClick() {
        String title = addBookTitle.getText().trim();
        String author = addBookAuthor.getText().trim();
        String isbn = addBookISBN.getText().trim();

        if (title.isEmpty() || author.isEmpty() || isbn.isEmpty()) {
            // Create an Alert for missing query or type
            Alert alert = new Alert(Alert.AlertType.ERROR); // Error alert type
            alert.setTitle("Invalid Input");
            alert.setHeaderText(null); // No header text
            alert.setContentText("All three title, author and ISBN fields must be filled in before adding the book.");
            alert.showAndWait(); // Show the alert and wait for user response
            return; // Exit method if validation fails
        }

        title = capitalizeFirstLetter(title);
        author = capitalizeFirstLetter(author);

        ArrayList<book> bookList = libObj.printBook();

        // Check if the ISBN already exists in the list
        for (book existingBook : bookList) {
            if (existingBook.getISBN().equals(isbn)) {
                // If ISBN exists, show an error alert
                Alert duplicateAlert = new Alert(Alert.AlertType.ERROR);
                duplicateAlert.setTitle("Duplicate ISBN.");
                duplicateAlert.setHeaderText(null);
                duplicateAlert.setContentText("The ISBN \"" + isbn + "\" is already used in the library. Please enter a unique ISBN.");
                duplicateAlert.showAndWait();
                return;
            }
        }

        // Create a new book object and add it to the list
        book newBook = new book();
        newBook.setVal(title, author, isbn, "Available", "null", null, null);

        // Add the new book to the list
        libObj.addBook(newBook);

        // Append the new book to the display
        /*StringBuilder build = new StringBuilder();
        for (book bookObj : libObj.printBook()) {
            build.append(bookObj.toString()).append("\n");
        }*/

        // Update the TextArea with the new list
        //showBook.setText(build.toString());

        // Show a success message
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Book Added Successfully");
        successAlert.setHeaderText(null); // No header text
        successAlert.setContentText("The book \"" + title + "\" by " + author + " has been added successfully.");
        successAlert.showAndWait(); // Show the alert and wait for user response

        addBookTitle.clear();
        addBookAuthor.clear();
        addBookISBN.clear();
    }

    private String capitalizeFirstLetter(String input) {
        String[] words = input.split(" ");
        StringBuilder capitalized = new StringBuilder();

        for (String word : words) {
            if (!word.isEmpty()) {
                capitalized.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1).toLowerCase()).append(" ");
            }
        }

        return capitalized.toString().trim();
    }

    @FXML
    protected void backToDashboard() {
        try {
            // Load the new scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml")); // Replace with your fxml path
            Parent root = loader.load();

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) addBookTitle.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Main Page");
            stage.show(); // Show the new scene

        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void handleLogOutButtonClick() {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Log Out Successful");
            alert.setHeaderText(null); // No header text
            alert.setContentText("You have successfully logout, have a nice day! ");
            alert.showAndWait();
            // Load the new scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login-view.fxml"));
            Parent root = loader.load();

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) addBookTitle.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Log In");
            stage.show(); // Show the new scene

        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}