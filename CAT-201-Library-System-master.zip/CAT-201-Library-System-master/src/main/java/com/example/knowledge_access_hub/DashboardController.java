package com.example.knowledge_access_hub;

import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.ArrayList;

public class DashboardController {

    @FXML
    private GridPane bookListGrid;

    @FXML
    private TextField searchInput;

    @FXML
    private ChoiceBox<String> searchType;

    private library libObj = new library();

    @FXML
    private void initialize() {
        configureGridPane();
        ViewAllBook();
    }

    private void configureGridPane() {
        // Define constraints for each column
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(15); // Adjust percentage as per your design
        col1.setHgrow(Priority.ALWAYS);

        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(15);
        col2.setHgrow(Priority.ALWAYS);

        ColumnConstraints col3 = new ColumnConstraints();
        col3.setPercentWidth(10);
        col3.setHgrow(Priority.ALWAYS);

        ColumnConstraints col4 = new ColumnConstraints();
        col4.setPercentWidth(15);
        col4.setHgrow(Priority.ALWAYS);

        ColumnConstraints col5 = new ColumnConstraints();
        col5.setPercentWidth(30);
        col5.setHgrow(Priority.ALWAYS);

        bookListGrid.getColumnConstraints().clear();
        bookListGrid.getColumnConstraints().addAll(col1, col2, col3, col4, col5);
        bookListGrid.setHgap(5); // Horizontal gap between columns
        bookListGrid.setVgap(10); // Vertical gap between rows
    }

    @FXML
    protected void onClickBooksButtonClick() {
        System.out.println("Books button clicked.");
        ViewAllBook();
    }

    @FXML
    protected void onShowAllBooksButtonClick() {
        System.out.println("Show All Books button clicked.");
        ViewAllBook();
    }

    @FXML
    protected void ViewAllBook() {
        if (bookListGrid == null) return;

        bookListGrid.getChildren().clear();
        ArrayList<book> allBooks = libObj.printBook();
        addGridHeader();
        populateBookList(allBooks);
    }

    private void addGridHeader() {
        String[] headers = {"Title", "Author", "ISBN", "Borrow Span", "Actions"};
        for (int col = 0; col < headers.length; col++) {
            Label header = new Label(headers[col]);
            header.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-alignment: center;");
            header.setMaxWidth(Double.MAX_VALUE);
            header.setAlignment(Pos.CENTER); // Center-align the headers
            bookListGrid.add(header, col, 0);
        }
    }

    private void populateBookList(ArrayList<book> allBooks) {
        int rowIndex = 1; // Start from row 1 (row 0 is header)
        for (book bookObj : allBooks) {
            addBookToGrid(bookObj, rowIndex);
            rowIndex++;
        }
    }

    private void addBookToGrid(book bookObj, int rowIndex) {
        // Title column
        Label title = new Label(bookObj.getTitle());
        title.setAlignment(Pos.CENTER);
        title.setMaxWidth(Double.MAX_VALUE);

        // Author column
        Label author = new Label(bookObj.getAuthor());
        author.setAlignment(Pos.CENTER);
        author.setMaxWidth(Double.MAX_VALUE);

        // ISBN column
        Label isbn = new Label(bookObj.getISBN());
        isbn.setAlignment(Pos.CENTER);
        isbn.setMaxWidth(Double.MAX_VALUE);

        // Borrowed Duration column
        Label borrowedDuration = new Label();
        if (bookObj.getDate() != null && !bookObj.getDate().isEmpty()) {
            borrowedDuration.setText(calculateBorrowDuration(bookObj.getDate()));
        } else {
            borrowedDuration.setText("-");
        }
        borrowedDuration.setAlignment(Pos.CENTER);
        borrowedDuration.setMaxWidth(Double.MAX_VALUE);

        // Actions column (Show Details button)
        Button showDetailsButton = new Button("Show Details");
        showDetailsButton.setAlignment(Pos.CENTER);
        HBox actionBox = new HBox(showDetailsButton);
        actionBox.setAlignment(Pos.CENTER);

        // Switch Button column
        SwitchButton toggleSwitch = new SwitchButton("Avail", "N/A", "Available".equals(bookObj.getStatus()));
        toggleSwitch.setOnMouseClicked(e -> {
            if ("Available".equals(bookObj.getStatus())) {
                handleBorrowBook(bookObj);
                bookObj.setStatus("Borrowed");
            } else {
                handleReturnBook(bookObj);
                bookObj.setStatus("Available");
            }
            toggleSwitch.setActive("Available".equals(bookObj.getStatus()));
            ViewAllBook();
        });
        toggleSwitch.setAlignment(Pos.CENTER); // Center alignment for the switch button

        // Add all components to the grid
        bookListGrid.addRow(rowIndex, title, author, isbn, borrowedDuration, actionBox, toggleSwitch);
    }



    private String calculateBorrowDuration(String borrowDate) {
        try {
            java.time.LocalDate borrow = java.time.LocalDate.parse(borrowDate);
            java.time.LocalDate today = java.time.LocalDate.now();
            java.time.Period period = java.time.Period.between(borrow, today);

            StringBuilder duration = new StringBuilder();
            if (period.getYears() > 0) duration.append(period.getYears()).append(" year(s) ");
            if (period.getMonths() > 0) duration.append(period.getMonths()).append(" month(s) ");
            if (period.getDays() > 0) duration.append(period.getDays()).append(" day(s)");

            return duration.toString().trim();
        } catch (Exception e) {
            e.printStackTrace();
            return "-";
        }
    }

    private void handleBorrowBook(book bookObj) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("borrowDetails.fxml"));
            Parent root = loader.load();

            BorrowDetailsController controller = loader.getController();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.setTitle("Borrow Book");
            stage.showAndWait();

            String[] userInfo = controller.handleOkButtonClick();
            if (userInfo != null) {
                bookObj.borrowBook(userInfo[1], userInfo[0], userInfo[2]);
                libObj.updateBookListInFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleReturnBook(book bookObj) {
        bookObj.returnBook();
        libObj.updateBookListInFile();
    }

    @FXML
    protected void onSearchButtonClick() {
        String query = searchInput.getText().trim();
        String type = searchType.getValue();

        if (query.isEmpty() || type == null) {
            displayError("Please enter a query and select a search type.");
            return;
        }

        ArrayList<book> filteredBooks = switch (type) {
            case "Title" -> libObj.searchBookByTitle(query);
            case "Author" -> libObj.searchBookByAuthor(query);
            case "ISBN" -> libObj.searchBookByISBN(query);
            default -> new ArrayList<>();
        };

        if (filteredBooks.isEmpty()) {
            displayError("No books found matching your query.");
        } else {
            bookListGrid.getChildren().clear();
            addGridHeader();
            populateBookList(filteredBooks);
        }
    }

    private void displayError(String message) {
        bookListGrid.getChildren().clear();
        Label errorLabel = new Label(message);
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 14px;");
        bookListGrid.add(errorLabel, 0, 1);
    }

    @FXML
    protected void handleAddButtonClick() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("addBook.fxml"));
            Stage stage = (Stage) searchInput.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Add Book");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void handleLogOutButtonClick() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("login-view.fxml"));
            Stage stage = (Stage) searchInput.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Log In");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class SwitchButton extends StackPane {
        private boolean isActive;
        private final TranslateTransition animation;
        private final Ellipse thumb;
        private final Label label;

        private static final double SWITCH_WIDTH = 70;
        private static final double SWITCH_HEIGHT = 25;
        private static final double THUMB_RADIUS_X = 10;
        private static final double THUMB_RADIUS_Y = 10;

        public SwitchButton(String activeText, String inactiveText, boolean initialState) {
            isActive = initialState;

            Rectangle background = new Rectangle(SWITCH_WIDTH, SWITCH_HEIGHT);
            background.setArcWidth(SWITCH_HEIGHT);
            background.setArcHeight(SWITCH_HEIGHT);
            background.setFill(isActive ? Color.LIGHTGREEN : Color.LIGHTGRAY);

            thumb = new Ellipse(THUMB_RADIUS_X, THUMB_RADIUS_Y);
            thumb.setFill(Color.WHITE);
            thumb.setTranslateY(SWITCH_HEIGHT / 2);
            thumb.setTranslateX(isActive ? SWITCH_WIDTH - THUMB_RADIUS_X * 2 + 7 : -SWITCH_WIDTH / 2 + THUMB_RADIUS_X + 38);

            label = new Label(isActive ? activeText : inactiveText);
            label.setStyle("-fx-font-size: 12px; -fx-text-fill: black;");

            animation = new TranslateTransition(Duration.millis(200), thumb);
            animation.setOnFinished(e -> label.setText(isActive ? activeText : inactiveText));

            Pane switchPane = new Pane(background, thumb);
            switchPane.setPrefSize(SWITCH_WIDTH, SWITCH_HEIGHT);
            getChildren().addAll(switchPane, label);

            setOnMouseClicked(e -> toggleSwitch(background, activeText, inactiveText));
        }

        public void setActive(boolean active) {
            isActive = active;

            double endTranslateX = isActive ? SWITCH_WIDTH - THUMB_RADIUS_X * 2 - 7 : 4;
            thumb.setTranslateX(endTranslateX);
            label.setText(isActive ? "Borrow" : "Not Available");
        }

        private void toggleSwitch(Rectangle background, String activeText, String inactiveText) {
            isActive = !isActive;
            double endTranslateX = isActive ? SWITCH_WIDTH - THUMB_RADIUS_X * 2 - 7 : 4;
            animation.setByX(endTranslateX - thumb.getTranslateX());
            animation.play();
            background.setFill(isActive ? Color.LIGHTBLUE : Color.RED);
        }
    }
}
