package com.example.knowledge_access_hub;

public class Account {
    private String code, pass;

    public void setVal(String c, String p){
        code = c;
        pass = p;
    }

    public String getCode(){
        return code;
    }

    public String getPass(){
        return pass;
    }

    @Override
    public String toString(){ //a superclass, override it so that the class have a custom string representing the object, the name 'toString' cannot be change
        return "Member Code: " + code + "\t" + "Password: " + pass;
    }
}