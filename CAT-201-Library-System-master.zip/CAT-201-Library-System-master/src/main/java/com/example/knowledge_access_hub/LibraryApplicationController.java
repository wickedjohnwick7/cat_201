/*
package com.example.knowledge_access_hub;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.*;
import java.util.ArrayList;
import java.util.stream.Collectors;
import javafx.collections.FXCollections;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class LibraryApplicationController {
    private library libObj = new library();

    @FXML
    private Label output;

    @FXML
    private TextField input;

    @FXML
    private TextField searchInput;

    @FXML
    private TextArea showBook;

    @FXML
    private TextArea searchResult;

    @FXML
    private ChoiceBox<String> searchType;

    @FXML
    private TextArea addBookTitle;

    @FXML
    private TextArea addBookAuthor;


    @FXML
    protected void onSubmitButtonClick() {
        // Get the text from the TextField and print it
        String inputText = input.getText();
        System.out.println("User input: " + inputText);
        // Optionally, you can set it in the Label or process it further
        output.setText("You entered: " + inputText);
    }

    @FXML
    protected void ViewAllBook(){
        showBook(libObj.printBook());
    }

    @FXML
    protected void showBook(ArrayList<book> bookList){
        StringBuilder build = new StringBuilder();
        for (book bookObj : bookList){
            build.append(bookObj.toString()).append("\n");
        }
        showBook.setText(build.toString());
    }

    @FXML
    protected void onSearchButtonClick() {
        String query = searchInput.getText().trim();
        String type = searchType.getValue();

        if (query.isEmpty() || type == null) {
            searchResult.setText("Please enter a query and select a search type.");
            return;
        }

        ArrayList<book> bookList = libObj.printBook();
        ArrayList<book> filteredBooks;

        // Filter books based on search type
        if ("Title".equals(type)) {
            filteredBooks = (ArrayList<book>) bookList.stream().filter(book -> book.getTitle().toLowerCase().contains(query.toLowerCase())).collect(Collectors.toList());
        }
        else if ("Author".equals(type)) {
            filteredBooks = (ArrayList<book>) bookList.stream().filter(book -> book.getAuthor().toLowerCase().contains(query.toLowerCase())).collect(Collectors.toList());
        }
        else {
            searchResult.setText("Invalid search type selected.");
            return;
        }

        // Display search results
        if (filteredBooks.isEmpty()) {
            searchResult.setText("No books found matching your query.");
        }
        else {
            StringBuilder results = new StringBuilder();
            for (book bookObj : filteredBooks) {
                results.append(bookObj.toString()).append("\n");
            }
            searchResult.setText(results.toString());
        }
    }

    @FXML
    protected void onAddButtonClick() {
        String title = addBookTitle.getText().trim();
        String author = addBookAuthor.getText().trim();

        if (title.isEmpty() || author.isEmpty()) {
            // Create an Alert for missing query or type
            Alert alert = new Alert(AlertType.ERROR); // Error alert type
            alert.setTitle("Invalid Input");
            alert.setHeaderText(null); // No header text
            alert.setContentText("Both title and author fields must be filled in before adding the book.");
            alert.showAndWait(); // Show the alert and wait for user response
            return; // Exit method if validation fails
        }

        ArrayList<book> bookList = libObj.printBook();

        // Create a new book object and add it to the list
        book newBook = new book();
        newBook.setVal(title, author); // Assuming setVal sets the title and author

        // Add the new book to the list
        libObj.addBook(newBook);

        // Append the new book to the display
        StringBuilder build = new StringBuilder();
        for (book bookObj : libObj.printBook()) {
            build.append(bookObj.toString()).append("\n");
        }

        // Update the TextArea with the new list
        showBook.setText(build.toString());

        // Show a success message
        Alert successAlert = new Alert(AlertType.INFORMATION);
        successAlert.setTitle("Book Added Successfully");
        successAlert.setHeaderText(null); // No header text
        successAlert.setContentText("The book \"" + title + "\" by " + author + " has been added successfully.");
        successAlert.showAndWait(); // Show the alert and wait for user response
    }


}
 */