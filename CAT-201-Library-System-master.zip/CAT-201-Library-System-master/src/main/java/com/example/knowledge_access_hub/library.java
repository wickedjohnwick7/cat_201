package com.example.knowledge_access_hub;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.stream.Collectors;

import java.io.FileWriter;
import java.io.BufferedWriter;

public class library {
    private ArrayList<book> BookList= new ArrayList<>();
    private final String csvFile = "src/main/resources/Book.csv"; //file path

    public library(){
        loadBook();
    }

    public void loadBook(){
        BookList.clear(); //clear the booklist before everytime load new data from the file
        String line;
        File myFile = new File(csvFile);
        if(myFile.exists()){
            try(BufferedReader read = new BufferedReader(new FileReader(myFile));){
                while((line = read.readLine()) != null) {
                    String[] dataColumn = line.split(",");
                    if(dataColumn.length == 7){
                        book bookObj = new book();
                        //String borrowerName = (dataColumn[4] == null || dataColumn[4].isEmpty()) ? null : dataColumn[4];  //trying
                        bookObj.setVal(dataColumn[0], dataColumn[1], dataColumn[2], dataColumn[3], dataColumn[4], dataColumn[5], dataColumn[6]);
                        BookList.add(bookObj);
                    }
                }
            }
            catch(IOException e){
                e.printStackTrace();
            }
        }
    }

    public ArrayList<book> printBook(){
        return BookList;
    }



    /*
    public void loadFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                // Split each line by the delimiter (comma)
                String[] data = line.split(delimiter);

                // Process the data (printing to console for example)
                for (String value : data) {
                    System.out.print(value + " ");  // Print each value separated by space
                }
                System.out.println(); // New line after each row
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     */

    // Method to update the file with the current list of books
    public void updateBookListInFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFile))) {
            for (book bookObj : BookList) {
                writer.write(bookObj.getTitle() + "," + bookObj.getAuthor() + "," + bookObj.getISBN() + "," + bookObj.getStatus() + "," + bookObj.getBorrowerName() + "," + bookObj.getIC() + "," + bookObj.getDate());
                writer.newLine();  // Add a new line after each book entry
            }
        } catch (IOException e) {
            e.printStackTrace();  // Print the stack trace if an error occurs
        }
    }

    // Method to add a new book to the list and update the file
    public void addBook(book newBook) {
        BookList.add(newBook);  // Add the new book to the list
        updateBookListInFile();  // Update the file with the new booklist
    }

    public void deleteBookByTitle(String title) {
        book bookToDelete = null;

        for (book b : BookList) { // Iterate over the ArrayList
            if (b.getTitle() != null && b.getTitle().equals(title)) { // Match title
                bookToDelete = b; // Mark for deletion
                break; // Exit loop after finding the match
            }
        }

        if (bookToDelete != null) {
            BookList.remove(bookToDelete); // Remove the matched book
            System.out.println("Book with title '" + title + "' has been deleted.");
        } else {
            System.out.println("Book with title '" + title + "' not found.");
        }
    }


    public ArrayList<book> searchBookByTitle(String title) {
        return (ArrayList<book>) BookList.stream().filter(book -> book.getTitle().toLowerCase().startsWith(title.toLowerCase())).collect(Collectors.toList());
    }

    public ArrayList<book> searchBookByAuthor(String author) {
        return (ArrayList<book>) BookList.stream().filter(book -> book.getAuthor().toLowerCase().startsWith(author.toLowerCase())).collect(Collectors.toList());
    }

    public ArrayList<book> searchBookByISBN(String isbn) {
        return (ArrayList<book>) BookList.stream().filter(book -> book.getISBN().toLowerCase().startsWith(isbn)).collect(Collectors.toList());
    }


}