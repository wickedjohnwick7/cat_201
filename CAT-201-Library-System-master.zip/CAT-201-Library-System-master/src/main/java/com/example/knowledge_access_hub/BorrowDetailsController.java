package com.example.knowledge_access_hub;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BorrowDetailsController {

    @FXML
    private TextField icNumberField;

    @FXML
    private TextField nameField;

    @FXML
    private DatePicker datePicker;

    @FXML
    private Button okButton;

    @FXML
    private Button cancelButton;

    public String[] handleOkButtonClick() {
        // Collect data from input fields
        String icNumber = icNumberField.getText();
        String name = nameField.getText();
        String date = (datePicker.getValue() != null) ? datePicker.getValue().toString() : "";

        // Return user input as an array
        return new String[]{name, icNumber, date};
    }

    @FXML
    public void handleOkButtonClickAndClose() {
        // Process input (if needed)
        handleOkButtonClick();

        // Close the dialog window
        Stage stage = (Stage) okButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void handleCancelButtonClick() {
        // Close the dialog window when "Cancel" is clicked
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
}
